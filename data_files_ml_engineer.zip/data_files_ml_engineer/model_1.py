#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 30 11:53:49 2018

@author: c001642
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist,pdist
import pickle
import os

def df_preprocessor(user_assesment, user_interest):
    
    
    assesment_interest = pd.merge(user_assesment,user_interest,how='inner',on=['user_handle','assessment_tag'])
    del assesment_interest['user_assessment_date']
    del assesment_interest['date_followed']
    assesment_interest['user_assessment_score'] = assesment_interest['user_assessment_score'].astype(int)
    assesment_interest['user_assessment_score'] = np.log(assesment_interest['user_assessment_score'])
    
    return assesment_interest


def components_for_discretizer(assesment_interest):
    
    
    
    range_to_be_tested = range(5,15)
    feature_reconfigured = assesment_interest['user_assessment_score'].reshape(-1, 1)
    model_fit = [KMeans(n_clusters = n,init = 'random',n_init=10).fit(feature_reconfigured) for n in range_to_be_tested]
    cluster_centers = [each_model.cluster_centers_ for each_model in model_fit]
    euc_distance = [cdist(feature_reconfigured,each_center,'euclidean') for each_center in cluster_centers]   
    min_distance = [np.min(each_distance,axis = 1) for each_distance in euc_distance]
    #Calcuating the total sum of squares (SSE):
    tsse = sum(pdist(feature_reconfigured)**2)/feature_reconfigured.shape[0]
    #calculating the sse between the clusters:
    wsse = [sum (eac_dist **2) for eac_dist in min_distance]
    bsse = tsse - wsse
    #print (wsse)
    y_axis = wsse  #bsse/tsse
    cluster_variance_dict = dict(zip(range(5,15),y_axis))
    #print ("The dictionary with number of clusters as key and the variance as value",cluster_variance_dict)
    
    return int(min(cluster_variance_dict, key=cluster_variance_dict.get))


def unsupervised_discretization (assesment_interest,number_of_clusters):
    
    
    mypath= os.getcwd()
    ftre = assesment_interest['user_assessment_score'].reshape(-1, 1)
    kmeans = KMeans(n_clusters = number_of_clusters,init = 'random',n_init=10)
    model = kmeans.fit(ftre)   
    assesment_interest['rating'] = model.labels_
    del assesment_interest['user_assessment_score']
    #print (assesment_interest.head())
    
    pivoted_matrix = assesment_interest.pivot_table(
    values='rating', index='user_handle', columns='assessment_tag',fill_value= 0)
    
    keys = [x for x in range(0,len(pivoted_matrix.index.tolist()))]
    tup = zip(pivoted_matrix.index.tolist(),keys)
    mapping_dict_pivoted_matrix =dict(tup) 
    dict_mapping_pivoted_matrix = dict(zip(keys,pivoted_matrix.index.tolist())) 
    
    pickle.dump(mapping_dict_pivoted_matrix, open(str(mypath)+"fm1_map_dict.p", "wb"))
    pickle.dump(dict_mapping_pivoted_matrix, open(str(mypath)+"fm1_dict_map.p", "wb"))
    
    return pivoted_matrix


def df_processor(user_course_views, course_tags):
    
    
    mypath= os.getcwd()
    result_usr_interest_withtag = pd.merge(user_course_views,course_tags,  how='left', on='course_id')
    result_usr_interest_withtag ['updated_tag'] = result_usr_interest_withtag['course_tags']+"-"+result_usr_interest_withtag['level']
    del result_usr_interest_withtag['course_tags']
    del result_usr_interest_withtag['level']
    del result_usr_interest_withtag['course_id']
    test_sum =  result_usr_interest_withtag.groupby(['user_handle','updated_tag'],as_index=False).view_time_seconds.sum()
    test_sum = test_sum[test_sum['view_time_seconds'] != 0]
    
    test_sum['view_time_seconds'] = test_sum['view_time_seconds'].astype(str).astype(int)
    test_sum['log_view_time_seconds'] = np.log(test_sum['view_time_seconds'])
    #print (test_sum['log_view_time_seconds'].max())
    labels = [1,2,3,4]
    bins =[0,test_sum['log_view_time_seconds'].quantile(0.25),test_sum['log_view_time_seconds'].quantile(0.50) ,test_sum['log_view_time_seconds'].quantile(0.75),test_sum['log_view_time_seconds'].quantile(1)]
    test_sum['ratings'] = pd.cut(test_sum['log_view_time_seconds'], bins=bins, labels=labels)
    pivoted = test_sum.pivot_table(
    values='ratings', index='user_handle', columns='updated_tag',aggfunc = 'sum',fill_value=0)
    
    keys = [x for x in range(0,len(pivoted.index.tolist()))]
    tup = zip(pivoted.index.tolist(),keys)
    mapping_dict_pivoted =dict(tup) 
    dict_mapping_pivoted = dict(zip(keys,pivoted.index.tolist())) 
    
    pickle.dump(mapping_dict_pivoted, open(str(mypath)+"fm2_map_dict.p", "wb"))
    pickle.dump(dict_mapping_pivoted, open(str(mypath)+"fm2_dict_map.p", "wb"))
    
    
    return pivoted


def df_only_user_interests(user_interest):
    
    
    mypath= os.getcwd()
    del user_interest['date_followed']
    pivoted_interest = user_interest.pivot_table(columns=user_interest['interest_tag'],index=user_interest['user_handle'],aggfunc='size',fill_value=0)
    keys = [x for x in range(0,len(pivoted_interest.index.tolist()))]
    tup = zip(pivoted_interest.index.tolist(),keys)
    mapping_dict_pivoted_interest =dict(tup) 
    dict_mapping_pivoted_interest = dict(zip(keys,pivoted_interest.index.tolist())) 
    
    pickle.dump(mapping_dict_pivoted_interest, open(str(mypath)+"fm3_map_dict.p", "wb"))
    pickle.dump(dict_mapping_pivoted_interest, open(str(mypath)+"fm3_dict_map.p", "wb"))
    return pivoted_interest
    
    
    
    
  