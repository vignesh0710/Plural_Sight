#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 30 04:52:48 2018

@author: vigneshsureshbabu
"""

from flask import Flask,request,render_template

import pandas as pd
import sqlite3
import os
import pickle
from sklearn.metrics.pairwise import cosine_similarity




def find_top_n_users(cos_sim_df,map_dict,dict_mapping,n_users,user_id):
    
    """function to find the top 25 users
    """
    
    similar_users_handle_id = []
    if user_id not in map_dict:
        print ("The user_handle_id is not part of user_views data, please try a different user_handle_id")
    else: 
        indices = cos_sim_df.sort_values(by = map_dict[user_id],axis = 1,ascending = False).columns[0:n_users+1].tolist()
        if map_dict[user_id] in indices:
            indices.remove(map_dict[user_id])
        else:
            del indices[-1]
        for each_indice in indices:
            similar_users_handle_id.append(dict_mapping[each_indice])
    print (similar_users_handle_id)
    return similar_users_handle_id
    
def find_sim(user_handle):
    
    mypath = os.getcwd()
    fm1_top_n_users = [];fm2_top_n_users = [];fm3_top_n_users = [];
    fm1_map_dict = pickle.load(open(str(mypath)+"fm1_map_dict.p", "rb")); fm1_dict_map = pickle.load(open(str(mypath)+"fm1_dict_map.p", "rb"))
    fm2_map_dict = pickle.load(open(str(mypath)+"fm2_map_dict.p", "rb")); fm2_dict_map = pickle.load(open(str(mypath)+"fm2_dict_map.p", "rb"))
    fm3_map_dict = pickle.load(open(str(mypath)+"fm3_map_dict.p", "rb")); fm3_dict_map = pickle.load(open(str(mypath)+"fm3_dict_map.p", "rb"))
    fm1_cos_df = pd.DataFrame(cosine_similarity(feature_matrix_1));fm2_cos_df = pd.DataFrame(cosine_similarity(feature_matrix_2));fm3_cos_df = pd.DataFrame(cosine_similarity(feature_matrix_3))
    if user_handle in fm1_map_dict and user_handle in fm2_map_dict and user_handle in fm3_map_dict:
        fm1_top_n_users = find_top_n_users(fm1_cos_df,fm1_map_dict,fm1_dict_map,25,user_handle)
        fm2_top_n_users = find_top_n_users(fm2_cos_df,fm2_map_dict,fm2_dict_map,25,user_handle)
        fm3_top_n_users = find_top_n_users(fm3_cos_df,fm3_map_dict,fm3_dict_map,25,user_handle)
    elif user_handle in fm1_map_dict and user_handle in fm2_map_dict:
        fm1_top_n_users = find_top_n_users(fm1_cos_df,fm1_map_dict,fm1_dict_map,25,user_handle)
        fm2_top_n_users = find_top_n_users(fm2_cos_df,fm2_map_dict,fm2_dict_map,25,user_handle)
    elif user_handle in fm1_map_dict and user_handle in fm3_map_dict:
        fm1_top_n_users = find_top_n_users(fm1_cos_df,fm1_map_dict,fm1_dict_map,25,user_handle)
        fm3_top_n_users = find_top_n_users(fm3_cos_df,fm3_map_dict,fm3_dict_map,25,user_handle)
    elif user_handle in fm2_map_dict and user_handle in fm3_map_dict:
        fm2_top_n_users = find_top_n_users(fm2_cos_df,fm2_map_dict,fm2_dict_map,25,user_handle)
        fm3_top_n_users = find_top_n_users(fm3_cos_df,fm3_map_dict,fm3_dict_map,25,user_handle)
    elif user_handle in fm1_map_dict:
        fm1_top_n_users = find_top_n_users(fm1_cos_df,fm1_map_dict,fm1_dict_map,25,user_handle)
    elif user_handle in fm2_map_dict:
        fm2_top_n_users = find_top_n_users(fm2_cos_df,fm2_map_dict,fm2_dict_map,25,user_handle)
    else:
        fm3_top_n_users = find_top_n_users(fm3_cos_df,fm3_map_dict,fm3_dict_map,25,user_handle)
    
    
    return [fm1_top_n_users,fm2_top_n_users,fm3_top_n_users]
    
        
        
def fm1_records_fetcher(df1,df2,similar_users):
    
   
    
    assessment_interest_rows = []; 
    df1 = df1.loc[df1['user_handle'].isin(similar_users)]
    df2 = df2.loc[df2['user_handle'].isin(similar_users)]
    df2.columns = ['user_handle', 'assessment_tag','date_followed']
    assesment_interest = pd.merge(df1,df2,how='inner',on=['user_handle','assessment_tag'])
    del assesment_interest['user_assessment_date']
    assessment_interest_rows = assesment_interest.values.tolist()
    
    return assessment_interest_rows

def fm2_records_fetcher(df1,df2,similar_users):
    
   
    
    view_tags_rows = []; 
    df1 = df1.loc[df1['user_handle'].isin(similar_users)]
    view_tags = pd.merge(df1,df2,  how='left', on='course_id')
    view_tags ['updated_tag'] = view_tags['course_tags']+"-"+view_tags['level']
    del view_tags['course_tags']
    del view_tags['level']
    view_tags_rows = view_tags.values.tolist()
        
    return view_tags_rows


def fm3_records_fetcher(df,similar_users):
    
   
    
    only_interests_rows = []; 
    
    df = df.loc[df['user_handle'].isin(similar_users)]
    only_interests_rows = df.values.tolist()
        
    return only_interests_rows



def sql_cmd(list_of_similar_users):
    

    global df_course_views,df_user_interests,df_course_tags,df_user_assesment_scores;
    assessment_interest_rows = []; view_tags_rows = [];only_interests_rows = []; i = 0
    super_list = [];

    if len(list_of_similar_users[i]) > 0 and  len(list_of_similar_users[i+1]) > 0 and  len(list_of_similar_users[i+2]) > 0:
        
        assessment_interest_rows = fm1_records_fetcher(df_user_assesment_scores,df_user_interests,list_of_similar_users[i])
        view_tags_rows = fm2_records_fetcher(df_course_views,df_course_tags,list_of_similar_users[i+1])
        only_interests_rows = fm3_records_fetcher(df_user_interests,list_of_similar_users[i+2])
        
    elif len(list_of_similar_users[i]) > 0 and  len(list_of_similar_users[i+1]) > 0:
        assessment_interest_rows = fm1_records_fetcher(df_user_assesment_scores,df_user_interests,list_of_similar_users[i])
        view_tags_rows = fm2_records_fetcher(df_course_views,df_course_tags,list_of_similar_users[i+1])
        
    elif len(list_of_similar_users[i+1]) > 0 and  len(list_of_similar_users[i+2]) > 0:
        view_tags_rows = fm2_records_fetcher(df_course_views,df_course_tags,list_of_similar_users[i+1])
        only_interests_rows = fm3_records_fetcher(df_user_interests,list_of_similar_users[i+2])
        
    elif len(list_of_similar_users[i]) > 0 and len(list_of_similar_users[i+2]) > 0:
         assessment_interest_rows = fm1_records_fetcher(df_user_assesment_scores,df_user_interests,list_of_similar_users[i])
         only_interests_rows = fm3_records_fetcher(df_user_interests,list_of_similar_users[i+2])
         
    elif len(list_of_similar_users[i]) > 0:
        assessment_interest_rows = fm1_records_fetcher(df_user_assesment_scores,df_user_interests,list_of_similar_users[i])
        
    elif len(list_of_similar_users[i+1]) > 0:
        view_tags_rows = fm2_records_fetcher(df_course_views,df_course_tags,list_of_similar_users[i+1])
    
    else:
        only_interests_rows = fm3_records_fetcher(df_user_interests,list_of_similar_users[i+2])
    print ("assessment_interest_rows---->",assessment_interest_rows)
    print ("view_tags_rows---->",view_tags_rows)
    print ("only_interests_rows---->",only_interests_rows)
    super_list.append(assessment_interest_rows);super_list.append(view_tags_rows);super_list.append(only_interests_rows);
        
    return super_list
        

app = Flask(__name__)


@app.route('/',methods=['GET', 'POST'])
def home():
    return render_template('home.html')
    
    
@app.route('/result',methods=['GET', 'POST'])
def view():
    
    ip = request.form['user_handle']
    user_ip_handle = int(ip)
  
    list_of_similar_users = find_sim(user_ip_handle)
    data = sql_cmd(list_of_similar_users)
    return render_template('pagination.html',row_row = data)
    
        #return str("The user_handle is not in the given data to find similarities. Please populate the user attributes first")
    

if __name__ == "__main__":
    
    mypath = os.getcwd()
    global feature_matrix_1,feature_matrix_2,feature_matrix_3;
   
    con_op = sqlite3.connect(str(mypath)+"/dense_matrix.db") 
    con_ip = sqlite3.connect(str(mypath)+"/plural_sight.db") 
    feature_matrix_1 = pd.read_sql_query("SELECT * FROM feature_matrix_1;", con_op)
    feature_matrix_2 = pd.read_sql_query("SELECT * FROM feature_matrix_2;", con_op)
    feature_matrix_3 = pd.read_sql_query("SELECT * FROM feature_matrix_3;", con_op)
    df_course_views =  pd.read_sql_query("SELECT * FROM user_course_views;", con_ip)
    df_user_interests =  pd.read_sql_query("SELECT * FROM user_interests;", con_ip)
    df_course_tags= pd.read_sql_query("SELECT * FROM course_tags;", con_ip)
    df_user_assesment_scores =  pd.read_sql_query("SELECT * FROM user_assessment_scores;", con_ip)
    
    app.run(port = 8081,debug = True)
    