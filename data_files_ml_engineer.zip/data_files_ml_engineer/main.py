#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 30 11:43:57 2018

@author: c001642
"""


import sqlite3
#import sys
import os
import pandas as pd
from utilities import create_db, db_to_pandasDF, matrix_factorization, dense_matrix
import _pickle as cPickle
from model_1 import df_preprocessor, components_for_discretizer, unsupervised_discretization, df_processor, df_only_user_interests


def main():
    
    global df_course_views, df_user_interests, df_course_tags, df_user_assesment_scores
    file_names = create_db(mypath,con,control)
    #print (file_names)
    list_df = db_to_pandasDF(file_names,con)
    df_course_views = list_df[2]; df_user_interests = list_df[3]; df_course_tags = list_df[0];df_user_assesment_scores = list_df[1];
    df_user_interests.columns = ['user_handle', 'assessment_tag','date_followed']
    
    model_1_merged = df_preprocessor(df_user_assesment_scores,df_user_interests)
    model_1_merged = unsupervised_discretization(model_1_merged,components_for_discretizer (model_1_merged))
    feature_matrix_1 = dense_matrix(matrix_factorization(model_1_merged)[0], 0.90, matrix_factorization(model_1_merged)[1])
    model_2_merged = df_processor(df_course_views,df_course_tags)
    feature_matrix_2 = dense_matrix(matrix_factorization(model_2_merged)[0], 0.70, matrix_factorization(model_2_merged)[1])
    df_user_interests.columns = ['user_handle', 'interest_tag','date_followed']
    model_3_merged = df_only_user_interests(df_user_interests)
    feature_matrix_3 = dense_matrix(matrix_factorization(model_3_merged)[0], 0.90, matrix_factorization(model_3_merged)[1])  
    feature_matrix_1.to_sql('feature_matrix_1',op_con,flavor='sqlite',if_exists='replace',index=False)
    feature_matrix_2.to_sql('feature_matrix_2',op_con,flavor='sqlite',if_exists='replace',index=False)
    feature_matrix_3.to_sql('feature_matrix_3',op_con,flavor='sqlite',if_exists='replace',index=False)
    
    print ("")
    #print (feature_matrix_3.shape)
    
    
    
    


if __name__ == "__main__":
    #mypath = input("Enter the path to the folder containing the data (csv) files: ")
    mypath = os.getcwd()
    #print (mypath)
    con = sqlite3.connect(str(mypath)+"/plural_sight.db") 
    op_con = sqlite3.connect(str(mypath)+"/dense_matrix.db")
    control = con.cursor()
    op_control = op_con.cursor()
    df_course_views =  pd.DataFrame(); df_user_interests =  pd.DataFrame(); df_course_tags= pd.DataFrame(); df_user_assesment_scores =  pd.DataFrame(); 
    main()
    con.close()
    op_con.close()
                        
                         