#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 29 19:08:34 2018

@author: vigneshsureshbabu
"""

from os import listdir
import csv
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD

def type_mapper(column_value):
    
    if str(type(column_value)) == "<class 'str'>" and column_value.isdigit() == False:
        return "TEXT"
    elif str(type(column_value)) == "<class 'str'>" and column_value.isdigit() == True:
        return "INTEGER"
    
    
def create_db(mypath,con,control):
    
    file_names = []
    
    for each_file in listdir(mypath):
        if "." in each_file and each_file[each_file.index("."):] == ".csv":
            cols = [];to_db = []; file_names.append(each_file)
            with open(mypath +"//"+each_file) as f:
                cols = f.readline().strip().replace('"', '').split(",")
                for col_num in range(len(cols)):
                    if col_num == 0:
                        if_col_type = None
                        for i, line in enumerate(f):
                            if i == 0:
                                if_col_type = type_mapper(line.strip().replace('"', '').split(",")[col_num])
                                break
                        if_cmd = "CREATE TABLE IF NOT EXISTS " + str(each_file[:each_file.index(".")]) + " (" + str(cols[col_num]) + " " +str(if_col_type)  +");"
        
                        control.execute(if_cmd)
                    else:
                        else_col_type = None
                        for i, line in enumerate(f):
                            if i == 0:
                                else_col_type = type_mapper(line.strip().replace('"', '').split(",")[col_num])
                                break
                        else_cmd = "ALTER TABLE " + str(each_file[:each_file.index(".")]) + " ADD COLUMN "+ " " + str(cols[col_num]) +" " + str(else_col_type) +";"
                        control.execute(else_cmd)
     
            with open(mypath +"//"+each_file,'rt') as fin:  
                question_mark = "("
                dr = csv.DictReader(fin) 
                for each in dr:
                    rows = [];
                    for n in range(len(cols)):
                        rows.append(each[cols[n]])
                    to_db.append(tuple(rows))

            for n in range(len(cols)):
                if n + 1 == len(cols):
                    question_mark += "?)"

                else:
                    question_mark += "?, "
           
            insert_cmd = "INSERT INTO " + str(each_file[:each_file.index(".")])+ " "  +str(tuple(cols )) + " VALUES "     +   str(question_mark)+";" 
            control.executemany(insert_cmd,to_db)
            con.commit()
    #con.close()
    #print (file_names)
    return file_names

def db_to_pandasDF(names,connection):
    
    
    list_df = []
    #print (type(names))
    for each_name in sorted(names):
        list_df.append(pd.read_sql_query("SELECT * FROM " + str (each_name[:each_name.index(".")])+";", connection))
    #print(list_df)
        
    return list_df


def matrix_factorization(pivoted_matrix):
    
    piv_compressed = csr_matrix(pivoted_matrix)
    unprocessed_matrix = TruncatedSVD(n_components=piv_compressed.shape[1]-1)
    unprocessed_matrix_after_tsvd = unprocessed_matrix.fit(piv_compressed)
    variance = unprocessed_matrix_after_tsvd.explained_variance_ratio_
    
    return variance,piv_compressed

def dense_matrix(variance, maximum_variance,piv_compressed):
   
    step = 0.0    
    features = 0
    for each in variance:    
        step += each
        features += 1
        if step >= maximum_variance:
            break
        
    dense_feature_matrix = pd.DataFrame(TruncatedSVD(n_components=features, random_state=50).fit(piv_compressed).transform(piv_compressed))  

    
    return dense_feature_matrix

